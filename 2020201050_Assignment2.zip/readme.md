 # SSD Assignment 2

 ## Frameworks used
 1. I have used bootstrap for spacing the elements, i.e. features like grid and flex containers provided by bootstrap.
 2. I have used jquery to provide scrolling animation on the home landing page.


I have created 3 pages- about me, skills and projects. I have tried to make the page responsive as far as I can, but still the navbar on the projects page is coming below some of the content, and I couldn't figure out the reason for that. I have used dummy text on the pages.

Link for running website is `akshat2412.github.io`